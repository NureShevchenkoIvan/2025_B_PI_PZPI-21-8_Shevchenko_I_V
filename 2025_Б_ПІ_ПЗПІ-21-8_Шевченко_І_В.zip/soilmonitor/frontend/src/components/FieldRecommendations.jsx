import React from "react";

const OPTIMAL_VALUES = {
  wheat: { moisture: 35, nitrogen: 30, phosphorus: 25, potassium: 20 },
  corn: { moisture: 40, nitrogen: 35, phosphorus: 30, potassium: 25 },
  default: { moisture: 30, nitrogen: 20, phosphorus: 20, potassium: 20 },
};

const CROP_MAP = {
  "пшениця": "wheat",
  "кукурудза": "corn"
};

export default function FieldRecommendations({ sensors, field, weather }) {
  if (!sensors || sensors.length === 0 || !field) return null;

  const cropKey = CROP_MAP[field.crop?.toLowerCase()] || "default";
  const optimal = OPTIMAL_VALUES[cropKey];

  // групуємо по сенсору та беремо останні зчитування
  const latestBySensor = {};
  for (const s of sensors) {
    if (!latestBySensor[s.sensorName] || new Date(s.timestamp) > new Date(latestBySensor[s.sensorName].timestamp)) {
      latestBySensor[s.sensorName] = s;
    }
  }
  const latest = Object.values(latestBySensor);
  const today = new Date().toISOString().slice(0, 10);
  const recent = latest.filter(s => s.timestamp?.slice(0, 10) === today);

  if (recent.length === 0) return <p>Немає актуальних показників для сьогоднішньої дати.</p>;

  const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length;
  const moistureAvg = avg(recent.map(s => s.data.moisture));
  const nAvg = avg(recent.map(s => s.data.npk.nitrogen));
  const pAvg = avg(recent.map(s => s.data.npk.phosphorus));
  const kAvg = avg(recent.map(s => s.data.npk.potassium));
  const rainNext3Days = weather?.daily?.precipitation_sum?.slice(0, 3)?.reduce((a, b) => a + b, 0) || 0;

  return (
    <div style={{ marginTop: '2rem' }}>
      <h3>🔍 Рекомендації</h3>

      <p>
        💧 Вологість ґрунту: {moistureAvg.toFixed(1)}% (оптимум: {optimal.moisture}%)<br />
        {moistureAvg < optimal.moisture
          ? rainNext3Days > 5
            ? 'Очікуються опади. Полив не обовʼязковий.'
            : 'Рекомендується полив. Недостатня вологість.'
          : 'Полив не потрібен. Волога в нормі.'}
      </p>

      <p>
        🧪 Поживні речовини:<br />
        - Азот: {nAvg.toFixed(1)} (оптимум: {optimal.nitrogen})<br />
        - Фосфор: {pAvg.toFixed(1)} (оптимум: {optimal.phosphorus})<br />
        - Калій: {kAvg.toFixed(1)} (оптимум: {optimal.potassium})<br />
        {(nAvg < optimal.nitrogen || pAvg < optimal.phosphorus || kAvg < optimal.potassium)
          ? 'Рекомендується внести добрива згідно з дефіцитом.'
          : 'Добрив не потрібно. Рівні в нормі.'}
      </p>
    </div>
  );
}