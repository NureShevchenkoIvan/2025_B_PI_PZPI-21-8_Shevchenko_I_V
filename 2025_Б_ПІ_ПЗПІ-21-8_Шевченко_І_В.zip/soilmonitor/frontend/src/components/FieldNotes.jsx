import React, { useEffect, useState } from 'react';

export default function FieldNotes({ fieldId }) {
  const [notes, setNotes] = useState([]);
  const [text, setText] = useState('');
  const [editingNoteId, setEditingNoteId] = useState(null);

  const fetchNotes = async () => {
    const res = await fetch(`http://localhost:5000/api/fields/${fieldId}/notes`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    });
    const data = await res.json();
    setNotes(data.reverse());
    setEditingNoteId(null);
  };

  const submitNote = async () => {
    if (!text.trim()) return;
    await fetch(`http://localhost:5000/api/fields/${fieldId}/note`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ text })
    });
    setText('');
    fetchNotes();
  };

  const updateNote = async (noteId, newText) => {
    await fetch(`http://localhost:5000/api/fields/${fieldId}/notes/${noteId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ text: newText })
    });
    fetchNotes();
  };

  const deleteNote = async (noteId) => {
    if (!window.confirm('Ви впевнені, що хочете видалити нотатку?')) return;
    await fetch(`http://localhost:5000/api/fields/${fieldId}/notes/${noteId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
    fetchNotes();
  };

  useEffect(() => { fetchNotes(); }, [fieldId]);

  return (
    <div style={{ marginTop: '2rem' }}>
      <h3>📝 Нотатки</h3>
      <textarea
        rows={4}
        placeholder="Введіть нову нотатку..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        style={{ width: '100%', padding: '0.5rem' }}
      />
      <button onClick={submitNote} style={{ marginTop: '0.5rem' }}>Додати нотатку</button>

      <ul style={{ marginTop: '1rem' }}>
        {notes.map((note) => (
          <li key={note._id} style={{ marginBottom: '1rem' }}>
            <strong>{new Date(note.createdAt).toLocaleString()}:</strong>
            <br />
            {editingNoteId === note._id ? (
              <>
                <textarea
                  value={note.text}
                  onChange={(e) => setNotes(prev =>
                    prev.map(n => n._id === note._id ? { ...n, text: e.target.value } : n)
                  )}
                  rows={3}
                  style={{ width: '100%', marginTop: '0.5rem' }}
                />
                <button onClick={() => updateNote(note._id, note.text)}>💾 Зберегти</button>
                <button onClick={() => setEditingNoteId(null)} style={{ marginLeft: '0.5rem' }}>❌ Скасувати</button>
              </>
            ) : (
              <>
                <p style={{ marginTop: '0.5rem', whiteSpace: 'pre-line' }}>{note.text}</p>
                <button onClick={() => setEditingNoteId(note._id)}>✏️ Редагувати</button>
                <button onClick={() => deleteNote(note._id)} style={{ marginLeft: '0.5rem' }}>🗑️ Видалити</button>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}