import React, { useEffect, useState } from "react";
import Sidebar from "./Sidebar";
import { Outlet } from "react-router-dom";
import { Box } from "@mui/material";
import API from "../services/api";

export default function MainLayout() {
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    API.get("/auth/me")
      .then((res) => setIsAdmin(res.data.role === "admin"))
      .catch(() => setIsAdmin(false));
  }, []);

  return (
    <Box sx={{ display: "flex" }}>
      <Sidebar isAdmin={isAdmin} />
      <Box sx={{ flexGrow: 1, p: 3 }}>
        <Outlet />
      </Box>
    </Box>
  );
}
