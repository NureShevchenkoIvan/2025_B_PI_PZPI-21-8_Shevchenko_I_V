import React from "react";
import {
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Box,
  Typography,
  Divider,
  Button
} from "@mui/material";
import {
  Dashboard,
  Event,
  Settings,
  AdminPanelSettings,
  Logout
} from "@mui/icons-material";
import { useNavigate } from "react-router-dom";

const Sidebar = ({ isAdmin }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token"); // або що там зберігається
    navigate("/login");
  };

  const items = [
    { text: "Головна", icon: <Dashboard />, path: "/dashboard" },
    { text: "Календар", icon: <Event />, path: "/tasks" },
    { text: "Налаштування", icon: <Settings />, path: "/profile" },
  ];

  if (isAdmin) {
    items.push({ text: "Адмін-панель", icon: <AdminPanelSettings />, path: "/admin" });
  }

  return (
    <Drawer
      variant="permanent"
      anchor="left"
      sx={{
        width: 240,
        flexShrink: 0,
        [`& .MuiDrawer-paper`]: {
          width: 240,
          boxSizing: "border-box",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          bgcolor: "#f5f5f5",
          borderRight: "1px solid #ddd"
        }
      }}
    >
      <Box>
        <Box sx={{ p: 2, textAlign: "center" }}>
          <Typography variant="h6" fontWeight="bold">
            🌱 SoilMonitor
          </Typography>
        </Box>
        <Divider />
        <List>
          {items.map((item) => (
            <ListItem
              key={item.text}
              button=""
              onClick={() => navigate(item.path)}
              sx={{ px: 3 }}
            >
              <ListItemIcon>{item.icon}</ListItemIcon>
              <ListItemText primary={item.text} />
            </ListItem>
          ))}
        </List>
      </Box>

      <Box sx={{ p: 2 }}>
        <Button
          variant="outlined"
          fullWidth
          color="error"
          startIcon={<Logout />}
          onClick={handleLogout}
        >
          Вийти
        </Button>
      </Box>
    </Drawer>
  );
};

export default Sidebar;