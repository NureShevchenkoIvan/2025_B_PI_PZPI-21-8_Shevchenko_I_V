import React, { useState } from 'react';
import {
  LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid,
} from 'recharts';

const groupByPeriod = (data, periodDays) => {
  const now = new Date();
  const cutoff = new Date(now.getTime() - periodDays * 24 * 60 * 60 * 1000);
  return data.filter(d => new Date(d.timestamp) >= cutoff);
};

export default function FieldCharts({ data }) {
  const [period, setPeriod] = useState(7);
  const [sensor, setSensor] = useState("");

  const allSensors = [...new Set(data.map(d => d.sensorName))];

  const filteredData = groupByPeriod(
    data
      .filter(d => !sensor || d.sensorName === sensor)
      .map(d => ({
        timestamp: new Date(new Date(d.timestamp).getTime() + 3 * 60 * 60 * 1000).toISOString().slice(0, 16).replace('T', ' '),
        temperature: d.data.temperature,
        moisture: d.data.moisture,
        nitrogen: d.data.npk?.nitrogen ?? null,
        phosphorus: d.data.npk?.phosphorus ?? null,
        potassium: d.data.npk?.potassium ?? null,
      })),
    period
  );

  return (
    <div style={{ marginTop: '2rem' }}>
      <h3>📈 Графіки показників</h3>

      <label>📡 Сенсор: </label>
      <select onChange={(e) => setSensor(e.target.value)} value={sensor}>
        <option value="">Усі</option>
        {allSensors.map(name => (
          <option key={name} value={name}>{name}</option>
        ))}
      </select>

      <label style={{ marginLeft: '1rem' }}>⏱️ Період: </label>
      <select onChange={(e) => setPeriod(Number(e.target.value))} value={period}>
        <option value={1}>1 день</option>
        <option value={7}>7 днів</option>
        <option value={30}>30 днів</option>
      </select>

      {filteredData.length === 0 ? (
        <p>Недостатньо даних для обраного сенсора або періоду.</p>
      ) : (
        <>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={filteredData}>
              <CartesianGrid stroke="#ccc" />
              <XAxis dataKey="timestamp" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="temperature" stroke="#ff7300" name="Температура (°C)" />
              <Line type="monotone" dataKey="moisture" stroke="#007aff" name="Вологість (%)" />
            </LineChart>
          </ResponsiveContainer>

          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={filteredData}>
              <CartesianGrid stroke="#ccc" />
              <XAxis dataKey="timestamp" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="nitrogen" stroke="#00c49f" name="Азот (N)" />
              <Line type="monotone" dataKey="phosphorus" stroke="#8884d8" name="Фосфор (P)" />
              <Line type="monotone" dataKey="potassium" stroke="#ffbb28" name="Калій (K)" />
            </LineChart>
          </ResponsiveContainer>
        </>
      )}
    </div>
  );
}