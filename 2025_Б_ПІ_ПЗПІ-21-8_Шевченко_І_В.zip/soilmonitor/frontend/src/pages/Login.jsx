import React, { useState } from 'react';
import { TextField, Button, Box, Typography } from '@mui/material';
import API from '../services/api';
import { useNavigate } from 'react-router-dom';
import { Link } from "react-router-dom";

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post('/auth/login', form);
      localStorage.setItem('token', res.data.token);
      navigate('/dashboard');
    } catch (err) {
      if (err.response?.status === 403) {
        alert(err.response.data.error || 'Ваш акаунт заблоковано.');
      } else {
        alert('Невірна електронна пошта або пароль');
      }
    }
  };

  return (
    <Box maxWidth={400} mx="auto" mt={10}>
      <Typography variant="h5" mb={2}>Вхід</Typography>
      <form onSubmit={handleSubmit}>
        <TextField fullWidth margin="normal" label="Email" name="email" onChange={handleChange} />
        <TextField fullWidth margin="normal" label="Пароль" type="password" name="password" onChange={handleChange} />
        <Button fullWidth type="submit" variant="contained" color="primary">Увійти</Button>
      </form>
      <Typography variant="body2">
        Не маєте акаунту? <Link to="/register">Зареєструватися</Link>
      </Typography>
    </Box>
    
  );
}
