import React, { useEffect, useState } from 'react';

export default function AdminPanel() {
  const [users, setUsers] = useState([]);
  const [editId, setEditId] = useState(null);
  const [editData, setEditData] = useState({});

  const fetchUsers = async () => {
    try {
      const res = await fetch('http://localhost:5000/api/admin/users', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });

      if (!res.ok) {
        if (res.status === 403) {
          throw new Error('У вас немає прав доступу до цієї сторінки');
        }
        throw new Error('Помилка при завантаженні користувачів');
      }

      const data = await res.json();
      setUsers(data);
    } catch (error) {
      alert(error.message);
    }
  };


  const toggleBlock = async (id) => {
    await fetch(`http://localhost:5000/api/admin/users/${id}/block`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
    fetchUsers();
  };

  const deleteUser = async (id) => {
    if (!window.confirm('Ви впевнені?')) return;
    await fetch(`http://localhost:5000/api/admin/users/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
    fetchUsers();
  };

  const startEdit = (user) => {
    setEditId(user._id);
    setEditData({ name: user.name, email: user.email, role: user.role });
  };

  const handleChange = (e) => {
    setEditData({ ...editData, [e.target.name]: e.target.value });
  };

  const saveEdit = async (id) => {
    await fetch(`http://localhost:5000/api/admin/users/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify(editData)
    });
    setEditId(null);
    fetchUsers();
  };

  useEffect(() => { fetchUsers(); }, []);

  return (
    <div>
      <h2>🔧 Адміністративна панель</h2>
      <table border="1" cellPadding="6">
        <thead>
          <tr>
            <th>Ім’я</th><th>Email</th><th>Роль</th><th>Блоковано</th><th>Дії</th>
          </tr>
        </thead>
        <tbody>
          {users.map(u => (
            <tr key={u._id}>
              <td>
                {editId === u._id
                  ? <input name="name" value={editData.name} onChange={handleChange} />
                  : u.name}
              </td>
              <td>
                {editId === u._id
                  ? <input name="email" value={editData.email} onChange={handleChange} />
                  : u.email}
              </td>
              <td>
                {editId === u._id
                  ? (
                    <select name="role" value={editData.role} onChange={handleChange}>
                      <option value="user">user</option>
                      <option value="admin">admin</option>
                    </select>
                  ) : u.role}
              </td>
              <td>{u.blocked ? 'Так' : 'Ні'}</td>
              <td>
                {editId === u._id
                  ? <>
                      <button onClick={() => saveEdit(u._id)}>💾 Зберегти</button>
                      <button onClick={() => setEditId(null)}>❌ Скасувати</button>
                    </>
                  : <button onClick={() => startEdit(u)}>✏️ Редагувати</button>
                }
                <button onClick={() => toggleBlock(u._id)}>{u.blocked ? 'Розблокувати' : 'Блокувати'}</button>
                <button onClick={() => deleteUser(u._id)}>Видалити</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
