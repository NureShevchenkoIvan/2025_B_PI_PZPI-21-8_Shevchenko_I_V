import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  MapContainer,
  TileLayer,
  Polygon,
  Marker,
  Popup,
  useMapEvents,
} from "react-leaflet";
import L from "leaflet";
import axios from "axios";
import "leaflet/dist/leaflet.css";

import FieldCharts from "../components/FieldCharts";
import FieldRecommendations from "../components/FieldRecommendations";
import FieldNotes from "../components/FieldNotes";
import FieldDocuments from "../components/FieldDocuments";

export default function FieldDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [field, setField] = useState(null);
  const [sensors, setSensors] = useState([]);
  const [adding, setAdding] = useState(false);
  const [newSensor, setNewSensor] = useState(null);
  const [movingSensorId, setMovingSensorId] = useState(null);
  const [weather, setWeather] = useState(null);
  const [readings, setReadings] = useState([]);
  const [editField, setEditField] = useState(false);
  const [fieldForm, setFieldForm] = useState({});
  const [period, setPeriod] = useState(7);
  const [sensorFilter, setSensorFilter] = useState("");

  const fetchField = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/fields`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      const found = res.data.find((f) => f._id === id);
      setField(found);
      setFieldForm({
        name: found.name,
        crop: found.crop,
        sowingDate: found.sowingDate?.slice(0, 10),
      });
    } catch (err) {
      console.error("Помилка завантаження поля", err);
    }
  };

  const fetchSensors = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/sensors?fieldId=${id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      setSensors(res.data);
    } catch (err) {
      console.error("Помилка завантаження сенсорів", err);
    }
  };

  const fetchReadings = async () => {
    try {
      const res = await axios.get(
        `http://localhost:5000/api/sensor-data?fieldId=${id}&period=${period}`,
        { headers: { Authorization: `Bearer ${localStorage.getItem("token")}` } }
      );
      setReadings(res.data);
    } catch (err) {
      console.error("Помилка завантаження зчитувань", err);
    }
  };

  const fetchWeather = async () => {
    if (!field) return;
    const center = field.boundary[Math.floor(field.boundary.length / 2)];
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${center.lat}&longitude=${center.lng}&daily=temperature_2m_max,precipitation_sum,windspeed_10m_max,relative_humidity_2m_max,winddirection_10m_dominant&current_weather=true&timezone=auto`;
    const res = await fetch(url);
    const data = await res.json();
    setWeather(data);
  };

  const createSensor = async () => {
    try {
      await axios.post(
        "http://localhost:5000/api/sensors",
        { ...newSensor, fieldId: id },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      setNewSensor(null);
      setAdding(false);
      fetchSensors();
    } catch (err) {
      console.error("Помилка збереження сенсора", err);
    }
  };

  const moveSensor = async (sensorId, location) => {
    try {
      await axios.put(
        `http://localhost:5000/api/sensors/${sensorId}`,
        { location },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      setMovingSensorId(null);
      fetchSensors();
    } catch (err) {
      console.error("Помилка переміщення сенсора", err);
    }
  };

  const renameSensor = async (sensorId, newName) => {
    try {
      await axios.put(
        `http://localhost:5000/api/sensors/${sensorId}`,
        { name: newName },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      fetchSensors();
    } catch (err) {
      console.error("Помилка перейменування сенсора", err);
    }
  };

  const deleteSensor = async (sensorId) => {
    if (!window.confirm("Ви впевнені, що хочете видалити сенсор?")) return;
    await axios.delete(`http://localhost:5000/api/sensors/${sensorId}`, {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    });
    fetchSensors();
  };

  const updateField = async () => {
    try {
      await axios.put(`http://localhost:5000/api/fields/${id}`, fieldForm, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      setEditField(false);
      fetchField();
    } catch (err) {
      console.error("Помилка оновлення поля", err);
    }
  };

  const deleteField = async () => {
    if (!window.confirm("Ви впевнені, що хочете видалити поле?")) return;
    await axios.delete(`http://localhost:5000/api/fields/${id}`, {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    });
    navigate("/");
  };

  const MapClickHandler = () => {
    useMapEvents({
      click(e) {
        const { lat, lng } = e.latlng;

        if (movingSensorId) {
          moveSensor(movingSensorId, { lat, lng });
          return;
        }

        if (!adding || !field) return;

        const name = prompt("Назва сенсора:");
        if (!name) return;

        setNewSensor({ name, location: { lat, lng } });
      },
    });

    return null;
  };

  useEffect(() => {
    fetchField();
    fetchSensors();
  }, []);

  useEffect(() => {
    fetchReadings();
  }, [period]);

  useEffect(() => {
    if (field) fetchWeather();
  }, [field]);

  if (!field) return <p>Завантаження...</p>;

  const center = field.boundary[Math.floor(field.boundary.length / 2)];
  const filteredReadings = sensorFilter
    ? readings.filter(r => r.sensorName === sensorFilter)
    : readings;

  return (
    <div style={{ padding: "1rem" }}>
      <h2>🗺 Поле: {field.name}</h2>
      <button onClick={() => setAdding(!adding)}>
        {adding ? "Скасувати додавання" : "Додати сенсор"}
      </button>
      {newSensor && (
        <div>
          <p>🆕 Новий сенсор: {newSensor.name}</p>
          <button onClick={createSensor}>✅ Зберегти сенсор</button>
        </div>
      )}

      <MapContainer 
        center={[center.lat, center.lng]} 
        zoom={16} 
        style={{ height: "400px", marginTop: "10px" }}
      >
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <Polygon 
          positions={field.boundary.map(p => [p.lat, p.lng])} 
          color="green" 
        />
        {sensors.map(sensor => (
          <Marker
            key={sensor._id}
            position={[sensor.location.lat, sensor.location.lng]}
            eventHandlers={{ click: () => setNewSensor(null) }}
          >
            <Popup>
              <strong>{sensor.name}</strong><br />
              📍 {sensor.location.lat.toFixed(5)}, {sensor.location.lng.toFixed(5)}<br />
              <button onClick={() => setMovingSensorId(sensor._id)}>
                Перемістити
              </button><br />
              <button onClick={() => {
                const newName = prompt("Нова назва сенсора", sensor.name);
                if (newName) renameSensor(sensor._id, newName);
              }}>
                ✏️ Редагувати назву
              </button><br />
              <button onClick={() => deleteSensor(sensor._id)}>
                🗑️ Видалити
              </button>
            </Popup>
          </Marker>
        ))}
        <MapClickHandler />
      </MapContainer>

      {editField ? (
        <div style={{ marginTop: "1rem" }}>
          <input 
            value={fieldForm.name} 
            onChange={(e) => setFieldForm({ ...fieldForm, name: e.target.value })} 
            placeholder="Назва поля" 
          />
          <select 
            value={fieldForm.crop} 
            onChange={(e) => setFieldForm({ ...fieldForm, crop: e.target.value })}
          >
            <option value="">Оберіть культуру</option>
            <option value="пшениця">пшениця</option>
            <option value="кукурудза">кукурудза</option>
            <option value="соняшник">соняшник</option>
          </select>
          <input 
            type="date" 
            value={fieldForm.sowingDate} 
            onChange={(e) => setFieldForm({ ...fieldForm, sowingDate: e.target.value })} 
          />
          <button onClick={updateField}>💾 Зберегти</button>
          <button 
            style={{ marginLeft: "1rem", color: "red" }} 
            onClick={deleteField}
          >
            🗑️ Видалити поле
          </button>
        </div>
      ) : (
        <div style={{ marginTop: "1rem" }}>
          <p>Культура: {field.crop}</p>
          <p>Дата посіву: {new Date(field.sowingDate).toLocaleDateString()}</p>
          <button onClick={() => setEditField(true)}>✏️ Редагувати поле</button>
        </div>
      )}

      {weather && (
        <div style={{ marginTop: "1rem" }}>
          <h3>🌤 Поточна погода</h3>
          <p>Температура: {weather.current_weather.temperature}°C</p>
          <p>Вітер: {weather.current_weather.windspeed} км/год</p>
          <p>Напрям вітру: {weather.current_weather.winddirection}°</p>
          {weather.daily && weather.daily.relative_humidity_2m_max && (
            <>
              <h4>Прогноз на 7 днів</h4>
              <ul>
                {weather.daily.time.map((date, i) => (
                  <li key={date}>
                    {new Date(date).toLocaleDateString()} — температура: {weather.daily.temperature_2m_max[i]}°C,
                    волога: {weather.daily.relative_humidity_2m_max[i]}%,
                    опади: {weather.daily.precipitation_sum[i]} мм,
                    вітер: {weather.daily.windspeed_10m_max[i]} км/год,
                    напрям: {weather.daily.winddirection_10m_dominant[i]}°
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}

      <FieldCharts data={filteredReadings} />
      <FieldRecommendations 
        sensors={filteredReadings} 
        field={field} 
        weather={weather} 
      />
      <FieldNotes fieldId={id} editable />
      <FieldDocuments fieldId={id} editable />
    </div>
  );
}