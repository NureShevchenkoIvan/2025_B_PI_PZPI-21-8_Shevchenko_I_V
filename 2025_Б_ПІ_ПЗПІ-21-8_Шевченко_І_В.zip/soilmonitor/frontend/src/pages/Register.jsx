import React, { useState } from 'react';
import { TextField, Button, Box, Typography } from '@mui/material';
import API from '../services/api';
import { useNavigate } from 'react-router-dom';

export default function Register() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    company: ''
  });

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = (field, value) => {
    switch (field) {
      case 'name':
        if (!value || value.length < 2) return 'Ім’я повинно містити щонайменше 2 символи';
        break;
      case 'email':
        if (!value || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return 'Некоректна email адреса';
        break;
      case 'password':
        if (!value || value.length < 8) return 'Пароль повинен містити щонайменше 8 символів';
        break;
      default:
        return '';
    }
    return '';
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));

    const error = validate(name, value);
    setErrors((prev) => ({ ...prev, [name]: error }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const newErrors = {};
    Object.entries(form).forEach(([key, value]) => {
      const error = validate(key, value);
      if (error) newErrors[key] = error;
    });

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      await API.post('/auth/register', form);
      navigate('/login');
    } catch (err) {
      alert('Помилка при реєстрації. Можливо, такий email вже існує.');
    }
  };

  return (
    <Box maxWidth={400} mx="auto" mt={10}>
      <Typography variant="h5" mb={2}>Реєстрація</Typography>
      <form onSubmit={handleSubmit} noValidate>
        <TextField
          fullWidth
          margin="normal"
          label="Ім’я"
          name="name"
          value={form.name}
          onChange={handleChange}
          error={!!errors.name}
          helperText={errors.name}
        />
        <TextField
          fullWidth
          margin="normal"
          label="Email"
          name="email"
          value={form.email}
          onChange={handleChange}
          error={!!errors.email}
          helperText={errors.email}
        />
        <TextField
          fullWidth
          margin="normal"
          label="Пароль"
          type="password"
          name="password"
          value={form.password}
          onChange={handleChange}
          error={!!errors.password}
          helperText={errors.password}
        />
        <TextField
          fullWidth
          margin="normal"
          label="Телефон (необов’язково)"
          name="phone"
          value={form.phone}
          onChange={handleChange}
        />
        <TextField
          fullWidth
          margin="normal"
          label="Компанія / господарство (необов’язково)"
          name="company"
          value={form.company}
          onChange={handleChange}
        />
        <Button fullWidth type="submit" variant="contained" color="primary">
          Зареєструватися
        </Button>
      </form>
    </Box>
  );
}