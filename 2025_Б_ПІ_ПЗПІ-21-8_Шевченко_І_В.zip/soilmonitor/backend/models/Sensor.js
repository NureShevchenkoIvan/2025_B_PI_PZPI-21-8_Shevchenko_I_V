import mongoose from 'mongoose';

const SensorSchema = new mongoose.Schema({
  fieldId: mongoose.Types.ObjectId,
  name: String,
  location: { lat: Number, lng: Number },
  data: {
    temperature: Number,
    moisture: Number,
    npk: {
      nitrogen: Number,
      phosphorus: Number,
      potassium: Number
    }
  },
  timestamp: Date
});

export default mongoose.model('Sensor', SensorSchema);
