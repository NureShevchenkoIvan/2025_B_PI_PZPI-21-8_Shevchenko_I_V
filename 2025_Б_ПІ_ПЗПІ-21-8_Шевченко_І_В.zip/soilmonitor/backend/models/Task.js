import mongoose from 'mongoose';

const TaskSchema = new mongoose.Schema({
  fieldId: { type: mongoose.Schema.Types.ObjectId, ref: 'Field' },
  title: String,
  type: { type: String, enum: ['Полив', 'Добрива', 'Обробка', 'Інше'], default: 'Інше' },
  date: Date,
  description: String,
  status: { type: String, enum: ['заплановано', 'виконано'], default: 'заплановано' },
  priority: { type: String, enum: ['низький', 'середній', 'високий'], default: 'середній' },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});

export default mongoose.model('Task', TaskSchema);