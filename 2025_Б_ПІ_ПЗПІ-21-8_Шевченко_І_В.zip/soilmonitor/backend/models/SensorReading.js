import mongoose from 'mongoose';

const SensorReadingSchema = new mongoose.Schema({
  fieldId: { type: mongoose.Schema.Types.ObjectId, ref: 'Field', required: true },
  sensorName: String,
  location: {
    lat: Number,
    lng: Number
  },
  data: {
    temperature: Number,
    moisture: Number,
    npk: {
      nitrogen: Number,
      phosphorus: Number,
      potassium: Number
    }
  },
  timestamp: { type: Date, default: Date.now }
});

export default mongoose.model('SensorReading', SensorReadingSchema);
