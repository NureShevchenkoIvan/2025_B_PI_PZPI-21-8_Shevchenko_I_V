import mongoose from 'mongoose';

const FieldSchema = new mongoose.Schema({
  name: { type: String, required: true },
  crop: { type: String },
  area: Number,
  boundary: [
    {
      lat: Number,
      lng: Number
    }
  ],
  sowingDate: Date,
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  notes: [
    {
      text: String,
      createdAt: { type: Date, default: Date.now }
    }
  ],
  documents: [
    {
      filename: String,
      url: String,
      uploadedAt: { type: Date, default: Date.now }
    }
  ],
});

export default mongoose.model('Field', FieldSchema);
