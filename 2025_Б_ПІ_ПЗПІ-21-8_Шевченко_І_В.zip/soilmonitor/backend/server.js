import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import cors from 'cors';
import path from 'path';

import authRoutes from './routes/auth.js';
import sensorRoutes from './routes/sensor.js';
import fieldRoutes from './routes/field.js';
import taskRoutes from './routes/task.js';
import adminRoutes from './routes/admin.js';
import sensorDataRoutes from './routes/sensorData.js';


dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/sensors', sensorRoutes);
app.use('/api/sensor-data', sensorDataRoutes);
app.use('/api/fields', fieldRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/admin', adminRoutes);
app.use('/uploads', express.static(path.resolve('uploads')));

const PORT = process.env.PORT || 5000;
mongoose.connect(process.env.MONGO_URI)
  .then(() => app.listen(PORT, '0.0.0.0', () => console.log(`Server running on ${PORT}`)))
  .catch(err => console.error(err));
