import User from '../models/User.js';
import Field from '../models/Field.js';
import Sensor from '../models/Sensor.js';
import SensorReading from '../models/SensorReading.js';
import Task from '../models/Task.js';

export const deleteUser = async (req, res) => {
  try {
    const userId = req.params.id;

    // поля, які належать користувачу
    const userFields = await Field.find({ owner: userId });
    const fieldIds = userFields.map(field => field._id);

    // видалення сенсорів, показів сенсорів, задач, прив’язаних до цих полів
    await Sensor.deleteMany({ fieldId: { $in: fieldIds } });
    await SensorReading.deleteMany({ fieldId: { $in: fieldIds } });
    await Task.deleteMany({ fieldId: { $in: fieldIds } });

    // видалення поля
    await Field.deleteMany({ owner: userId });

    // видалення цього самого користувача
    await User.findByIdAndDelete(userId);

    res.sendStatus(204);
  } catch (err) {
    console.error('Помилка при видаленні користувача:', err);
    res.status(500).json({ message: 'Помилка при видаленні користувача' });
  }
};
