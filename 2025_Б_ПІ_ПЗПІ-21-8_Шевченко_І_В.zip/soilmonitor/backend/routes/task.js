import express from 'express';
import Task from '../models/Task.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

router.get('/', authenticate, async (req, res) => {
  const tasks = await Task.find({ createdBy: req.user.id });
  res.json(tasks);
});

router.post('/', authenticate, async (req, res) => {
  try {
    const task = new Task({ ...req.body, createdBy: req.user.id });

    // перевірка обов’язкових полів
    if (!task.title || !task.type || !task.date || !task.fieldId) {
      return res.status(400).json({ message: "Всі обов’язкові поля мають бути заповнені" });
    }

    await task.save();
    res.status(201).json(task);
  } catch (err) {
    console.error("Помилка при створенні задачі:", err.message);
    res.status(500).json({ message: "Помилка при створенні задачі" });
  }
});

router.get('/upcoming', authenticate, async (req, res) => {
  try {
    const days = parseInt(req.query.days) || 3;
    const now = new Date();
    const end = new Date();
    end.setDate(now.getDate() + days);

    const tasks = await Task.find({
      date: { $gte: now, $lte: end },
      createdBy: req.user.id
    }).populate('fieldId', 'name');

    res.json(tasks);
  } catch (error) {
    console.error('Error fetching upcoming tasks:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

router.put('/:id/status', authenticate, async (req, res) => {
  const task = await Task.findOne({ _id: req.params.id, createdBy: req.user.id });
  if (!task) return res.sendStatus(404);
  task.status = 'виконано';
  await task.save();
  res.json(task);
});

router.delete('/:id', authenticate, async (req, res) => {
  const task = await Task.findOneAndDelete({ _id: req.params.id, createdBy: req.user.id });
  if (!task) return res.sendStatus(404);
  res.json({ message: "Задачу видалено" });
});

export default router;
